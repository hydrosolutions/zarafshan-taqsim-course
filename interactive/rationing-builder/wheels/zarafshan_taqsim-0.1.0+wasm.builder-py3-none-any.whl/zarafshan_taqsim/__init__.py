"""Reduced package for the block editor page only."""
