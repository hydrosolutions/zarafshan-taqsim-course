"""Reduced package for the static blocks demonstration only."""
