from dataclasses import dataclass

from taqsim.common import LossReason


@dataclass(frozen=True, slots=True)
class WaterGenerated:
    amount: float  # m³
    t: int  # timestep


@dataclass(frozen=True, slots=True)
class WaterReceived:
    amount: float
    source_id: str
    t: int


@dataclass(frozen=True, slots=True)
class WaterStored:
    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterReleased:
    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterLost:
    amount: float
    reason: LossReason
    t: int


@dataclass(frozen=True, slots=True)
class WaterSpilled:
    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterConsumed:
    """Water physically consumed (leaving the water system)."""

    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterDistributed:
    amount: float
    target_id: str
    t: int


@dataclass(frozen=True, slots=True)
class DeficitRecorded:
    required: float
    actual: float
    deficit: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterOutput:
    """Water available for downstream routing.

    For Demand nodes, includes both excess water and returned
    non-consumptive portion.
    """

    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterPassedThrough:
    """Records water passing through (for analysis, e.g., turbine power)."""

    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterEnteredReach:
    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterExitedReach:
    amount: float
    t: int


@dataclass(frozen=True, slots=True)
class WaterInTransit:
    amount: float
    t: int


NodeEvent = (
    WaterGenerated
    | WaterReceived
    | WaterStored
    | WaterReleased
    | WaterLost
    | WaterSpilled
    | WaterConsumed
    | WaterDistributed
    | DeficitRecorded
    | WaterOutput
    | WaterPassedThrough
    | WaterEnteredReach
    | WaterExitedReach
    | WaterInTransit
)
